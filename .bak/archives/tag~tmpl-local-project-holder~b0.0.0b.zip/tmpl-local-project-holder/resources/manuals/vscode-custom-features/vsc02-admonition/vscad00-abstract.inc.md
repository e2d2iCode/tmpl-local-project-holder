<!-- markdownlint-disable MD041-->
<div style="
    font-size: normal;
    margin: 0 15% 5ex 10%;
    min-width: 38em; max-width: 43em;"
>
<div style="font-size: 95%; text-align: justify;">

!!!Abstract markdown.extensions.admonition
    *This is a quick reference for VSCode's **`admonition extension`**, which allows to display
    messages in fancy and vibrant colored boxes and use icon + text headers to grab readers'
    attention. This extension is included in thestandard Markdown library. The full documentation is
    availbe on [Markdown's Officially Supported Extension's Website](https://python-markdown.github.io/extensions/admonition/).*

</div>
</div>
<!-- markdownlint-enable MD041-->
