<!-- markdownlint-disable MD041-->
*Admonition* can be customized using CSS. To understand how,
we first look at the HTML structure of an admonition. Then, we
show how to implement a custom *type* and how to customize its
look using CSS.
<!-- markdownlint-enable MD041-->
