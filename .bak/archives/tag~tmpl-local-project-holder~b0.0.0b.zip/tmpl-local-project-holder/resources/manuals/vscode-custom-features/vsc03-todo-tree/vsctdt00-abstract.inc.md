<!-- markdownlint-disable MD041 -->
<div style="min-width: 45em; font-size: normal; margin: 0 10% 5ex 5%;">
<div style="font-size: 95%; text-align: justify;">

!!!Abstract
    *This documentation provides a quick reference to VSCode's **`Todo-Tree`** extension. Its
    primary purpose is to describe the way it is configured in this project's workspace and how it is
    meant to be used.*

</div></div>
<!-- markdownlint-enable MD041-->
