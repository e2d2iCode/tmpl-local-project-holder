# README - @@PROJECT_NAME

This folder is not meant to be a versioned repository, but rather as a local folder structure that will itself contain one or more repositories. Note that it is not to be confused with a mono-repo either since its root folders are not meant to be versioned. The contents of the `workspace(s)` folder, however, *may* be versioned by itself or contain multiple subfolders, each of which being a mono-repo, a multi-repo or a simple folder.

- [Project's Description](#projects-description)
- [Project's Shell Structure](#projects-shell-structure)
- [Project's Roadmap and TODOs](#projects-roadmap-and-todos)
- [Projects' Authors and Acknowledgment](#projects-authors-and-acknowledgment)

## Project's Description

@@POJECT_DESCRIPTION

## Project's Shell Structure

Each folder of the template that was used to instantiate this project contains a `.gitkeep` file containing a description of its purpose. In addition, the folder `resources/manuals` contain several documents describing in more detail certain aspects of the template and its usage, and suggesting some best practices and conventions.

As a quick overview, and a reference of the template's structure once the unnecessary files and folders have been removed, the following tree shows the structure of the template:

```text
   .                                        "PROJECT(S) ROOT FOLDER"
   |                                         ```````````````````````````````````````````
  ├──   ~                              # Project's Backup and Archives
   |        ├──   ...                       # Sufolders and files ...
   |        └──  .gitkeep               # Describres the .bak folder purpose
   |
  ├──   deploy                        # Deployment Environement(s)
   |        ├──   ...                         # Sufolders and files ...
   |        └──  .gitkeep                 # Describres the deploy folder purpose
   |
  ├──   resources                   # Project's Resources
   |        ├──   ...                         # Sufolders and files ...
   |        └──  .gitkeep                 # Describres the resources folder purpose
   |
  ├──   workspace(s)              # Project's Workspace(s)
   |        ├──   ...                         # Sufolders and files ...
   |        └──  .gitkeep                 # Describres the workspace(s) folder purpose
   |
  └──  .gitkeep                         # Describres the template's core structure
```

## Project's Roadmap and TODOs

Planned features and improvements as well as known issues and other topics of interest concerning this template's development status and roadmap are embedded in its `.gitkeep` files in the form of [Todo Tree](https://marketplace.visualstudio.com/items?itemName=Gruntfuggly.todo-tree) comments. They can be viewed in the *Todo Tree* panel of [Visual Studio Code](https://code.visualstudio.com/) by installing the *Todo Tree* extension and opening the template's root folder in *Visual Studio Code* using the file named [vscode-index.code-workspace](vscode-index.code-workspace) and located at the root of this template's folder.

Note that, due to the custom tags that were used and that are defined in that latter file, opening this template exactly as just described is mandatory to get an exhaustive view of all the *Todo Tree* tags that this project contains.

For the record, let's list here the most important entries anyway:

- [ ]  @@ROADMAP_ENTRY_1, if applies
- [ ]  @@ROADMAP_ENTRY_2, if applies
- [ ]  etc ...

## Projects' Authors and Acknowledgment

- **@@AUTHOR_NAME** - *Initial work* - [@@USER_NAME](https://github.com/@@USER_NAME)

<!-- CHECK Make sure that all @@-Tags  were either replaced or deleted with their associated contents. Delete this comment only once this is done! [template]  -->
