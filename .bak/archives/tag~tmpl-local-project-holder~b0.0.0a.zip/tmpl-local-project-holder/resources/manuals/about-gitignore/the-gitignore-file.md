# The `.gitignore` file

<div style="margin: 0 auto 5ex auto; max-width: 600px;  font-size: 95%">

!!!Abstract
    <i>This documentation quickly references this project's configuration of
    <b><a href="https://code.visualstudio.com/docs">Visual Studio Code (VSCode)</a></b> and its
    recommended extensions. It details the non-trivial settings of the editor and describes how to use
    the associated features in the context of this project's development.</i>


<details open style="margin: 14pt 0pt 36pt 10pt">
<summary style="margin-left: -8pt; font-weight: bold; font-size: larger; font-variant: small-caps">
<span style="margin-left: 3pt">Table of contents<span></summary>

- [Overview](#overview)
- [Workspaces](#workspaces)
  - [Creating and saving workspaces](#creating-and-saving-workspaces)
  - [Configuring workspaces](#configuring-workspaces)

</details>

## Overview
