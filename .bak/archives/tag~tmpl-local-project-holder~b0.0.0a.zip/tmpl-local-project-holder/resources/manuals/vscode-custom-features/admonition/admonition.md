# Admonitions - *fancy note boxes*

***Extension:** `markdown.extensions.admonition`*
*Display messages in fancy and vibrant colored boxes and use icon + text headers to grab readers' attention.*

## Overview

Admonitions ("safety messages" or "hazard statements") can appear anywhere an ordinary body element can and are used to draw the reader's attention to a particular point.

<div style="
    font-size: normal;
    margin: 0 15% 5ex 10%;
    min-width: 38em; max-width: 43em;"
>
<div style="font-size: 95%; text-align: justify;">

!!! note

    This is the **note** admonition body

    !!! danger Danger Title
        This is the **danger** admonition body

        !!! success ""
            This is the **success** admonition body, with stripped out title and icons

            As shown below, there are plenty of other types to choose from !

</div>
</div>

## Syntax

The extension `markdown.extensions.admonition` provides the following syntax for admonitions:

<div style="
    font-size: normal;
    margin: 0 15% 5ex 10%;
    min-width: 38em; max-width: 43em;"
>
<div style="font-size: 95%; text-align: justify;">

<!-- markdownlint-disable MD046 -->
```markdown
    !!! <type> [Alternative Title | "" to hide the header]

    <paragraph>

    <paragraph>

    ...
```

</div>
</div>
<!-- markdownlint-enable MD046 -->

, where the  `<type>`  defines the overall style (icon and color) of the admonition
and the  `<paragraph>`  is a normal paragraph of text.

## Available Types

The  *types* to choose from are:

!!! Note
!!! tldr Tldr | Abstract | Summary
!!! info Info | Todo
!!! tip Tip | Hint
!!! done Done | Check | Success
!!! faq Faq | Help | Question
!!! warning
!!! attention
!!! caution
!!! fail Fail | Missing | Failure
!!! danger
!!! error
!!! bug
!!! snippet Snippet | Example
!!! cite Cite | Quote
