# Todo-Tree Extension

<div style="
    font-size: normal;
    margin: 0 15% 5ex 10%;
    min-width: 38em; max-width: 43em;"
>
<div style="font-size: 95%; text-align: justify;">

!!!Abstract
    <i>This documentation provides a quick reference to VSCode's Todo-Tree extension. Its primary
    purpose is to describe the way it is configured in this project's workspace and how it is meant to
    be used.</i>


<details open style="margin: 18pt 0pt 24pt 10pt">
<summary style="margin-left: -8pt; font-weight: bold; font-size: larger; font-variant: small-caps">
<span style="margin-left: 3pt">Table of contents<span></summary>

- [Extension's overview](#extensions-overview)
- [Project's predefined tags](#projects-predefined-tags)
  - [Categories' overview](#categories-overview)
  - [Details on categories and available tags](#details-on-categories-and-available-tags)
    - [Issues](#issues)
    - [Alerts](#alerts)
    - [Records](#records)
    - [Hunches](#hunches)
    - [Markers](#markers)
    - [Helpers](#helpers)
    - [Dividers](#dividers)

</details>

## Extension's overview

The extension [Todo-Tree][todo-tree] uses [ripgrep][ripgrep] to search the workspace for keywords
like `TODO`, `FIXME` or `NOTE` and displays the results in an interactive *tree view* that can be
sorted, filtered and exported.

The `TAGS` it looks for can be customized, and it can also be configured to further bundle the
results  into `SUBTAGS`. Those can also be highlighted in the editor according to a customizable
color scheme.

## Project's predefined tags

The following tables list the tags that are currently made available by the extension's configuration
defined in [@@PROJECT-NAME.code-workspace][workspace-settings].

<div style="margin: 0 auto 5ex auto; max-width: 600px;  font-size: 95%">

!!! INFO Note on icons
    The icons in use are the ones provided by the [octicons][icons-link] set. Due to poor and unstable
    support of colors, using alternative sets is not recommended.

</div>
</div>

### Categories' overview

The tags defined in this project's workspace are spliced into 7 disjoint categories which definitions are summarized in the table below. More details as well as the tags available in each category are provided in the next sections.

Category     | Description                                                     |
:----------- | :-------------------------------------------------------------- |
**[Issues][issues-section]**   | Tags identifying major issues and calling for immediate action   |
**[Alerts][alerts-section]**  | Tags pointing to issues which severity is not yet established  |
**[Helpers][helpers-section]**  | Tags which are used to hold information about the project       |
**[Markers][markers-section]**  | Tags identifying editable parts of the project like templates  |
**[Dividers][dividers-section]** | Tags which are used to visually segment the project's file     |
**[Records][records-section]**  | Tags containing general tasks meant to produce tasks' lists            |
**[Hunches][hunches-section]** | Tags referring to modifications not to be in the next release   |

### Details on categories and available tags

#### Issues

Tags identifying major issues and calling for immediate action. Freeing the project from all tags
falling into that category should be the developers' highest priority. No release should be
considered until every single one of them has been addressed and removed from the project, no
matter its present state and the location of the tags. For this reason, the extension should be
configured to display the tags from this category wherever the tree is generated from.

<div class="tag-table issues">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Description |
:-----:|:----:|:----|
<img class="bug-icon" src="./assets/icons/octicons/bug.svg" />| <tag class="bug-tag">BUG</tag> | Describes an identified bug (still) needing to be addressed.  |
<img class="fixme-icon" src="./assets/icons/octicons/alert.svg" />| <tag class="fixme-tag">FIXME</tag> | Formally identifies and describes something needing a fix.  |

</div>

#### Alerts

Tags pointing to issues whose severity is still to be established, but that are potentially damaging
enough to be considered as a threat. The tags from this category are typically transitional,
meaning that addressing such a tag is expected to yield its requalification as either a *record* or an
*issue* tag. Cleaning the project from all *alerts* should be every developer's 2nd highest priority,
right after clearing all tags marked as *issues*. Again, no release should be considered as long as
the todo-tree displays any of these tags.

<div class="tag-table alerts">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Description |
:-----:|:----:|:----|
<img class="check-icon" src="./assets/icons/octicons/checklist.svg" />| <tag class="check-tag">CHECK</tag>  | Points out that something needs to be checked or tested. |
<img class="temp-icon" src="./assets/icons/octicons/eye.svg" />| <tag class="temp-tag">TEMP</tag> | A temporary piece of code to be deleted in the short term.  |
<img class="review-icon" src="./assets/icons/octicons/clock.svg" />| <tag class="review-tag">REVIEW</tag> | Calls for something's critical  in an improvement aim.  |

</div>

#### Records

Tags that are used to produce to-do lists of different natures. Tags from this category are mostly
used to keep track of the project's progress and to make sure that none of the features expected to
be part of the next release  is forgotten. For the project to be considered as ready for release, all
tags from this category should be either addressed or moved to the *hunches* category.  As a result,
while this category is expected to be the most densely populated one among the generated tree at
the heart of every development phase, it should vanish completely when approaching a release.

<div class="tag-table records">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Description |
:-----:|:----:|:----|
<img class="test-icon" src="./assets/icons/octicons/tools.svg" />| <tag class="test-tag">TEST</tag>  | Documents a non-critical task that still needs to be done. |
<img class="todo-icon" src="./assets/icons/octicons/flame.svg" />| <tag class="todo-tag">TODO</tag>  | Documents a non-critical task that still needs to be done. |
<img class="finish-icon" src="./assets/icons/octicons/thumbsup.svg" />| <tag class="finish-tag">FINISH</tag>  | Documents a non-critical task that still needs to be done. |

</div>

#### Hunches

Low-priority tags refer to modifications that are not meant to be part of the next release, whether
because they are considered to be non-essential, or because the underlying features are not
advanced enough to qualify for inclusion. This category also includes all the tags referencing
changes that have been planned (independently of their status) as well as the eventual mentions of
ideas or proposals that have not yet been evaluated. Tags from this category have no impact on the
project's readiness for release, the reason why the extension may be safely configured to hide them
whenever the tree is generated from outside the development environment.

<div class="tag-table hunches">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Description |
:-----:|:----:|:----|
<img class="idea-icon" src="./assets/icons/octicons/light-bulb.svg" />| <tag class="idea-tag">IDEA</tag>  | Keeps track of a suggestion seemingly worth a consideration.     |
<img class="learn-icon" src="./assets/icons/octicons/mortar-board.svg" /> | <tag class="learn-tag">LEARN</tag>  | A topic of interest that should be studied, an article to read, etc ... |
<img class="improve-icon" src="./assets/icons/octicons/graph.svg" /> | <tag class="improve-tag">IMPROVE</tag>  | To Be Done: something that has not even been started yet |
<img class="roadmap-icon" src="./assets/icons/octicons/milestone.svg" /> | <tag class="roadmap-tag">ROADMAP</tag>  | To Be Done: something that has not even been started yet |
</div>

#### Markers

Tags identifying editable parts of the project, either by delimiting customizable areas or by being
themselves placeholders meant to be replaced. Tags from this category typically call for actions on a
template that are meant to happen at a pre-determined point in the project's life cycle. Depending on
its nature, each of these tags may be repeatedly needed and, thus, persist throughout all project's
life cycles, or serve only once and then be removed. As a result, whether or not their presence
impacts the project's release readiness must be evaluated on a case-by-case basis. It is however
very unlikely that any of them should be part of the project's final distribution.

<div class="tag-table markers">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Description |
:-----:|:----:|:----|
<img class="atat-icon" src="./assets/icons/octicons/typography.svg" />| <tag class="atat-tag">@@</tag> | Prefixes keywords that are placeholders for customizable values  |
<img class="edit-icon" src="./assets/icons/octicons/pencil.svg" />| <tag class="edit-tag">EDIT</tag>  | Highlights the beginning of an editable chunk of code like a template's customizable area.  |
<img class="option-icon" src="./assets/icons/octicons/share-android.svg" />| <tag class="option-tag">OPTION</tag> | Highlights a chunk of code that is one among other alternatives |

</div>

#### Helpers

Tags which are used to hold information about the project that is central enough to its development
that it is worth using the tree to keep track of them. In the same aim, tags from this category may
also be used to bookmark locations in the project that are of particular interest and, thus, need to be
accessed frequently and/or simply as a reminder for some easily forgettable action that is important
to be taken. These tags' lifetime typically spans over the whole development and has no impact on
whether the project can be released or not. As a consequence, the extension should be configured
to hide this category's tags whenever generating the tree from the release or the deployment
environment.

<div class="tag-table helpers">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Description |
:-----:|:----:|:----|
<img class="link-icon" src="./assets/icons/octicons/link.svg" />| <tag class="link-tag">LINK</tag> | Serves as shortcut to an editable region within, typically, templates |
<img class="note-icon" src="./assets/icons/octicons/info.svg" />| <tag class="note-tag">NOTE</tag>  | A general note or comment calling for no action of any kind     |

</div>

#### Dividers

Tags that are used to visually segment the project's file. The extension is configured to provide 6
levels of sectioning, starting with *parts* and *chapters* and ending with *sub-sub-sub-sections*.
Obviously, tags from this category call for no action at all and are intrinsically meant to never be
deleted; their number even has a vocation to increase with the size of the project and, thus, over
time. It is worth noting that the case of *dividers* is in complete contrast to this of *helpers*. Indeed,
unlike *helpers*, *dividers* have no interest at all in the listing ability of the extension. Instead, they
benefit from the fact that tags can be highlighted within the project's source files.

<div class="tag-table dividers">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TAG&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | Description |
:-----:|:----:|:----|
<img class="part-icon" src="./assets/icons/octicons/log.svg" />| <tag class="part-tag">PART</tag> | Separates parts by highlighting the *whole-line* |
<img class="chapter-icon" src="./assets/icons/octicons/book.svg" />| <tag class="chapter-tag">CHAPTER</tag> | Highlights a chapter using the *line* setting |
<img class="section-icon" src="./assets/icons/octicons/rows.svg" />| <tag class="section-tag">SECTION</tag> | Highlights a section using the *text-and-comment* setting  |
<img class="subsect-icon" src="./assets/icons/octicons/bookmark.svg" />| <tag class="subsect-tag">SUBSECTION</tag> | Highlights a sub-section using the *tag-and-comment* setting |
<img class="block-icon" src="./assets/icons/octicons/three-bars.svg" />| <tag class="block-tag">BLOCK</tag> | Highlights a "block". This can be paragraph, a list, etc ... |
<img class="item-icon" src="./assets/icons/octicons/triangle-right.svg" />| <tag class="item-tag">ITEM</tag> | Highlights an "item". This can be an entry from a list, an comment, an example, etc ... |

</div>

<!--project's files -->
[workspace-settings]: ../../../../personal/PROJECT-NAME.code-workspace

<!-- EXTENSION: Todo-Tree -->
<!-- external Links -->
[ripgrep]: <https://github.com/BurntSushi/ripgrep>
[icons-link]: <https://octicons.github.com/>
[todo-tree]: <https://marketplace.visualstudio.com/items?itemName=Gruntfuggly.todo-tree>

[issues-section]: #issues
[alerts-section]: #alerts
[helpers-section]: #helpers
[records-section]: #records
[hunches-section]: #hunches
[markers-section]: #markers
[dividers-section]: #dividers

<style>div. tag-table tag {
  width: 85%;
  padding: 0 .75ex 0 .6ex;
  display: inline-block;
  text-align: center;
}
div.tag-table img {
  height: 24px;
  margin-top: 8px;
}

.bug-tag {
 color: white;
 background-color: red;
}
.bug-icon {
  filter: invert(16%) sepia(76%) saturate(7012%) hue-rotate(358deg) brightness(102%) contrast(118%);
}

.fixme-tag {
 color: white;
 background-color: orangeRed;
}
.fixme-icon {
  filter: invert(44%) sepia(87%) saturate(5514%) hue-rotate(4deg) brightness(103%) contrast(107%);
}

.check-tag {
 color: black;
 background-color: orange;
}
.check-icon {
  filter: invert(76%) sepia(18%) saturate(7022%) hue-rotate(357deg) brightness(98%) contrast(108%);
}

.review-tag {
 color: black;
 background-color: gold;
}
.review-icon {
  filter: invert(76%) sepia(95%) saturate(1607%) hue-rotate(358deg) brightness(102%) contrast(106%);
}

.temp-tag {
 color: black;
 background-color: goldenRod;
}
.temp-icon {
  filter: invert(80%) sepia(54%) saturate(1608%) hue-rotate(345deg) brightness(90%) contrast(88%);
}

.finish-tag {
 color: white;
 background-color: blue;
}
.finish-icon {
  filter: invert(23%) sepia(69%) saturate(6642%) hue-rotate(229deg) brightness(95%) contrast(97%);
}

.test-tag {
 color: white;
 background-color: blue;
}
.test-icon {
  filter: invert(23%) sepia(69%) saturate(6642%) hue-rotate(229deg) brightness(95%) contrast(97%);
}

.todo-tag {
 color: white;
 background-color: blue;
}
.todo-icon {
  filter: invert(23%) sepia(69%) saturate(6642%) hue-rotate(229deg) brightness(95%) contrast(97%);
}

.idea-tag {
 color: white;
 background-color: darkSlateBlue;
}
.idea-icon {
  filter: invert(24%) sepia(96%) saturate(1262%) hue-rotate(228deg) brightness(84%) contrast(84%);
}

.improve-tag {
 color: white;
 background-color: darkSlateBlue;
}
.improve-icon {
  filter: invert(24%) sepia(96%) saturate(1262%) hue-rotate(228deg) brightness(84%) contrast(84%);
}

.learn-tag {
 color: white;
 background-color: darkSlateBlue;
}
.learn-icon {
  filter: invert(24%) sepia(96%) saturate(1262%) hue-rotate(228deg) brightness(84%) contrast(84%);
}

.roadmap-tag {
 color: white;
 background-color: darkSlateBlue;
}
.roadmap-icon {
  filter: invert(24%) sepia(96%) saturate(1262%) hue-rotate(228deg) brightness(84%) contrast(84%);
}

.atat-tag {
 color: deepPink;
 background-color: none;
}
.atat-icon {
  filter: invert(27%) sepia(72%) saturate(6772%) hue-rotate(316deg) brightness(102%) contrast(101%);
}

.edit-tag {
 color: white;
 background-color: rgb(128,0,128);
}
.edit-icon {
  filter: invert(10%) sepia(93%) saturate(4953%) hue-rotate(294deg) brightness(86%) contrast(109%);
}

.option-tag {
 color: rgb(255, 0, 255);
 background-color: none;
}
.option-icon {
  filter: invert(17%) sepia(99%) saturate(3837%) hue-rotate(300deg) brightness(125%) contrast(125%);
}

.link-tag {
 color: white;
 background-color: mediumPurple;
}
.link-icon {
  filter: invert(69%) sepia(31%) saturate(7437%) hue-rotate(219deg) brightness(86%) contrast(99%);
}

.note-tag {
 color: white;
 background-color: mediumPurple;
}
.note-icon {
  filter: invert(69%) sepia(31%) saturate(7437%) hue-rotate(219deg) brightness(86%) contrast(99%);
}

.part-tag {
 color: white;
 background-color: darkSlateGrey;
}
.part-icon {
  filter: invert(26%) sepia(55%) saturate(447%) hue-rotate(202deg) brightness(150%) contrast(87%);
}

.chapter-tag {
 color: white;
 background-color: olive;
}
.chapter-icon {
  filter: invert(47%) sepia(31%) saturate(3762%) hue-rotate(38deg) brightness(92%) contrast(101%);
}

.section-tag {
 color: white;
 background-color: darkOliveGreen;
}
.section-icon {
  filter: invert(42%) sepia(43%) saturate(631%) hue-rotate(48deg) brightness(92%) contrast(84%);
}

.subsect-tag {
 color: white;
 background-color: darkGreen;
}
.subsect-icon {
  filter: invert(26%) sepia(99%) saturate(1153%) hue-rotate(91deg) brightness(99%) contrast(107%);
}

.block-tag {
 color: lightGreen;
 background-color: none;
}
.block-icon {
  filter: invert(88%) sepia(19%) saturate(933%) hue-rotate(61deg) brightness(96%) contrast(94%);
}

.item-tag {
 color: limeGreen;
 background-color: none;
}
.item-icon {
  filter: invert(72%) sepia(29%) saturate(2106%) hue-rotate(66deg) brightness(90%) contrast(89%);
}

</style>
