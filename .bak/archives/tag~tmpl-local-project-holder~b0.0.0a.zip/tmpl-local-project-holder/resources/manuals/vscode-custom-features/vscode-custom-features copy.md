# Visual Studio Code's Custom Features

!!!Abstract
    <i>This documentation provides a quick reference to <code>Visual Studio Code</code>
    (VSCode) and its recommended extensions. It briefly recalls the editor's main concetpts, such as
    <code>workspaces</code>, and explains how certain of the recommended extensions are
    expected to be used.</i>


## Table of contents

1. **[VSCode](./vscode-editor/vscode-editor.md)**[:](./vscode-editor/vscode-editor.md)
        *[Generalities on the Visual Studio Code editor](./vscode-editor/vscode-editor.md)*
2. **[Todo-Tree](./todo-tree/todo-tree.md)**[:](./todo-tree/todo-tree.md)
        *[Add and manage TODOs in documents](./todo-tree/todo-tree.md)*
3. **[Admonition](./admonition/admonition.md)**[:](./admonition/admonition.md)
        *[Fancy Note Boxes](./admonition/admonition.md)*

## Generalities on VSCode's Editor

## The Admonition Extension

## The Todo-Tree Extension
