<!-- markdownlint-disable MD041 -->
<!--
All files within the `vscode-custom-features` should be mergeable into a single doucmentation, which requires the sectionning to be compatible. In particular, subfiles like the present one should have make this possible, file's content should be mergeable with the # Visual Studio Code's Custom Features -->
## Generalities on the Visual Studio Code editor

<div style="
    font-size: normal;
    margin: 0 15% 5ex 10%;
    min-width: 38em; max-width: 43em;"
>
<div style="font-size: 95%; text-align: justify;">

!!!Abstract
    <i>This documentation quickly references this project's configuration of
    <b><a href="https://code.visualstudio.com/docs">Visual Studio Code (VSCode)</a></b> and its
    recommended extensions. It details the non-trivial settings of the editor and describes how to use
    the associated features in the context of this project's development.</i>


<details open style="margin: 14pt 0pt 36pt 10pt">
<summary style="margin-left: -8pt; font-weight: bold; font-size: larger; font-variant: small-caps">
<span style="margin-left: 3pt">Table of contents<span></summary>

- [Generalities on the Visual Studio Code editor](#generalities-on-the-visual-studio-code-editor)
  - [Overview](#overview)
  - [Workspaces](#workspaces)
    - [Creating and saving workspaces](#creating-and-saving-workspaces)
    - [Configuring workspaces](#configuring-workspaces)

</details>

### Overview

*VSCode_ can be configured at three different levels, namely `User`, `Workspace`, and `Folder`,
which override each other in that order. The `workspace` concept is central to*VSCode*. The way it
has to be configured, in particular, greatly depends on whether it hosts a `single-root` or a
`multi-root` workspace which, as their names suggest, are `workspaces` containing one or multiple
(root) folders, respectively.

Not surprisingly,  `multi-root workspaces`, which this project is a case of, are more complex to
configure than `single-root` ones. This fact justifies providing a quick reference to the `workspace`
concept before going into the details of the specific configuration used in this project.

### Workspaces

A `workspace` is a collection of files and folders opened in the editor. A  `single-root workspace`
contains a single folder, while a `multi-root workspace` has several.

The concept of a workspace enables VS Code to:

- Configure settings applying only to specific folders.
- Persist [tasks-link][tasks-link] and [debugger launch][debugging-link] configurations.
- Store and restore UI states.
- Selectively enable or disable extensions only for that workspace.

#### Creating and saving workspaces

Creating a `workspace` is as simple as opening a folder or a set of folders in the editor. Once
opened, *VSCode* will automatically keep track of its state, which includes the last used layout.
*VSCode* saves the configuration of `single-root` workspaces in a folder named `.vscode` in the
workspace root directory. It does in a `<the-project-name``>.code-workspace` file for `multi-root`
workspaces; that file may lie wherever convenient, including a remote location.

<div style="margin: 0 auto 5ex auto; max-width: 600px;  font-size: 95%">

!!! note
    The syntax used by *VSCode* in the case of a `single-root workspace` lacks consistency. Indeed,
    until a `.code-workspace` file exists, the `Settings Panel` labels `User` and *Workspace* as the
    available configuration levels. Then, it surprisingly saves the preferences within a
    `.vscode/settings.json` file, although such location should be home to nothing else than
    *folder level settings*! This inconsistency is enhanced when defining and saving some
    preferences **first** and creating a `.code-workspace` **later**.

     One would expect the *workspace* configuration to be available in the `Workspace` tab of the
     editor's *Settings Panel*, but they are not. Instead, they now considered a `Folder` configuration.
     Such behavior makes sense when considering the saving location but makes none when
     focusing on the editor's UI. Everything happens as if the UI changed the nature of the settings.

</div>
</div>

It is worth pointing out that multiple versions of a `.code-workspace` file can coexist, which allows
one to save different configurations of the same workspace and switch between them easily.

#### Configuring workspaces

*VSCode* configuration happens at three levels: `User`, `Workspace`, and `Folder`, which override
each other in that order. The `Settings Panel` of the editor lets the user choose the level to edit and
updates the corresponding file:

- **User settings** are (typically) defined in the file `settings.json` located in the `.vscode` folder of
   the *user's home directory*. They then apply globally to all *VSCode* instances with the lowest
   priority.

- **Workspace settings** lie in the `.code-workspace`  that *VSCode* creates when choosing to
  [save a workspace][workspace-link]. These settings then apply to the opened workspace,
  overriding the *user's settings* but not the *folder's settings*.

- **Folder settings** are in the file `settings.json` located in the `.vscode` folder of the selected
`<root-folder>`. They apply, with the highest priority, to the whole contents of the enclosing folder.

Going through *VSCode*'s `Settings Panel` is not the only way to configure the editor. An alternative
consists in modifying the corresponding `json` files directly. That second method is much faster and,
in certain cases, gives access to more options than the graphical interface of the setting panel does.
However, it requires a good knowledge of the available settings and/or intensive use of the
documentation.

[tasks-link]: <https://code.visualstudio.com/docs/editor/tasks>
[debugging-link]: <https://code.visualstudio.com/docs/editor/debugging>
[workspace-link]: <https://code.visualstudio.com/docs/editor/workspaces>
<!-- markdownlint-enable MD041 -->
