# Visual Studio Code's Custom Features

!!!Abstract
    <i>This documentation provides a quick reference to <code>Visual Studio Code</code>
    (VSCode) and its recommended extensions. It briefly recalls the editor's main concetpts, such as
    <code>workspaces</code>, and explains how certain of the recommended extensions are
    expected to be used.</i>


## Generalities on VSCode's Editor

### Overview

### Workspaces

#### Creating and saving workspaces

#### Configuring workspaces

## The Admonition Extension

## The Todo-Tree Extension
